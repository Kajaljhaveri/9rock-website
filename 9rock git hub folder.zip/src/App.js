import React from 'react';
export default function App() { return <div>Hello from Disruptive Jewelry</div>; }